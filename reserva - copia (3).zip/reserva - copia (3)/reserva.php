<?php
$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_de_datos = "reserva";

$conexion =  mysqli_connect($host, $usuario, $contrasena, $base_de_datos);

$nombre = isset($_GET['nombre']) ? $_GET['nombre'] : '';
$hora_inicio = isset($_GET['hora-inicio']) ? $_GET['hora-inicio'] : '';
$hora_fin = isset($_GET['hora-fin']) ? $_GET['hora-fin'] : '';
$id_reserva = isset($_GET['id_reserva']) ? $_GET['id_reserva'] : '';



$consulta = "INSERT INTO podcast (`nombre`, `horainicio`, `horafin`) VALUES ('$nombre', '$hora_inicio', '$hora_fin')";
    
    $resultado = mysqli_query ($conexion, $consulta);

    if ($resultado == true) {
        echo "La reserva se ha agregado correctamente.";
    } else {
        echo "Error al agregar la reserva: " . $conexion->error;
        $conexion->close();
    }

    $consulta = "DELETE FROM `podcast` WHERE id = '$id_reserva'";
    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
        echo "La reserva se ha eliminado correctamente.";
    } else {
        echo "Error al eliminar la reserva: " . mysqli_error($conexion);
    }
?>


